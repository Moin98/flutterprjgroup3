import 'package:flutter/material.dart';
import 'shoes.dart';

class ShoesList extends StatelessWidget {
  final List<Shoes> shoesList = [
    Shoes(
        'Nike Air Max',
        'Nike',
        99.99,
        'assets/nike_air_max.jpg',
        'The Nike Air Max is a stylish and comfortable shoe suitable for everyday wear.'
    ),
    Shoes(
        'Adidas Ultraboost',
        'Adidas',
        129.99,
        'assets/adidas_ultraboost.jpg',
        'The Adidas Ultraboost is known for its responsive cushioning and sleek design.'
    ),
    // Add more Shoes objects here
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Shoes List'),
      ),
      body: ListView.builder(
        itemCount: shoesList.length,
        itemBuilder: (context, index) {
          return ListTile(
            leading: Image.asset(
              shoesList[index].photo,
              width: 50,
              height: 50,
            ),
            title: Text(shoesList[index].name),
            subtitle: Text('${shoesList[index].brand} - \$${shoesList[index].price.toStringAsFixed(2)}'),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => ShoesDetail(shoes: shoesList[index]),
                ),
              );
            },
          );
        },
      ),
    );
  }
}

class ShoesDetail extends StatelessWidget {
  final Shoes shoes;

  const ShoesDetail({Key? key, required this.shoes}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(shoes.name),
      ),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Image.asset(
              shoes.photo,
              width: 200,
              height: 200,
            ),
            SizedBox(height: 20),
            Text(
              'Brand: ${shoes.brand}',
              style: TextStyle(fontSize: 18),
            ),
            Text(
              'Price: \$${shoes.price.toStringAsFixed(2)}',
              style: TextStyle(fontSize: 18),
            ),
            Text(
              'Description: ${shoes.description}',
              style: TextStyle(fontSize: 18),
            ),
          ],
        ),
      ),
    );
  }
}
