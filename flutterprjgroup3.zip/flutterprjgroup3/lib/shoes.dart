class Shoes {

  String name;
  String brand;
  double price;
  String photo;
  String description;

  Shoes (this.name, this.brand, this.price, this.photo, this.description);
}